[![](https://img.shields.io/badge/Wahoo-Theme-00b0ff.svg?style=flat-square)][Wahoo]
![](https://img.shields.io/badge/License-MIT-707070.svg?style=flat-square)

# :hurtrealbad: _Hogan_

> [Fishshell](fishshell.com) Theme.

## Features

> Use the [powerline patched fonts](https://github.com/powerline/fonts) for best results.

+ Powerline displaying current path segments and git status.

+ `git` status segment becomes pink if the repository is touched / dirty.

+ Directory segments become red if `$status` is non-zero.

## Screenshot

<p align="center">
<img src="https://cloud.githubusercontent.com/assets/8317250/8264402/9061d7f4-1720-11e5-8ba8-dd150a6f7c6f.png">
</p>


# License

[MIT](http://opensource.org/licenses/MIT) © [Jorge Bucaran][Author] et [al](https://github.com/bucaran/batman/graphs/contributors)
[Author]: http://about.bucaran.me
[Wahoo]: https://github.com/bucaran/wahoo
